import { execFile, spawn } from "node:child_process";
import { createWriteStream, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { createServer } from "node:net";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { promisify } from "node:util";
import { gzipSync } from "node:zlib";
import { test as base, expect, type FrameLocator, type Page } from "@playwright/test";

export { expect };

// The backend's virtualenv (`uv sync`): its server, and the Python that seeds
// DuckDB/SQLite/Postgres/MySQL with the drivers the backend already depends on. In
// the release gate the installed wheel's server is what lives there.
const VENV_BIN = resolve(import.meta.dirname, "..", ".venv", "bin");

// Coordinates default to the connection-form defaults the suite uses.
export const CH_HOST = process.env.CLICKHOUSE_HOST ?? "localhost";
export const CH_PORT = process.env.CLICKHOUSE_PORT ?? "8123";
export const CH_USER = process.env.CLICKHOUSE_USER ?? "default";
export const CH_PASSWORD = process.env.CLICKHOUSE_PASSWORD ?? "";
const PG_HOST = process.env.PG_HOST ?? "localhost";
const PG_PORT = process.env.PG_PORT ?? "5432";
const PG_USER = process.env.PG_USER ?? "postgres";
const PG_PASSWORD = process.env.PG_PASSWORD ?? "";
const MY_HOST = process.env.MYSQL_HOST ?? "localhost";
const MY_PORT = process.env.MYSQL_PORT ?? "3306";
const MY_USER = process.env.MYSQL_USER ?? "root";
const MY_PASSWORD = process.env.MYSQL_PASSWORD ?? "";

// Not `test`: a name that generic may already hold someone's data, and the
// seeding drops it. Each worker seeds (and drops) its own database, so one
// worker's teardown can't pull the table out from under another's test.
// Postgres and MySQL use the same name. Read in a test, never at import time.
const dbName = (index: number) => `qvtest_${index}`;
export const chDb = () => dbName(test.info().parallelIndex);

// --- HTTP ------------------------------------------------------------------

type Json = Record<string, any>;

/** Call the app's REST API; throws on a non-2xx unless `ok: false` is passed. */
export async function api(
  url: string,
  opts: { method?: string; json?: unknown; headers?: Record<string, string>; ok?: false } = {},
): Promise<{ status: number; body: any }> {
  const method = opts.method ?? (opts.json === undefined ? "GET" : "POST");
  const res = await fetch(url, {
    method,
    headers: { "content-type": "application/json", ...opts.headers },
    body: opts.json === undefined ? undefined : JSON.stringify(opts.json),
    signal: AbortSignal.timeout(10_000),
  });
  const text = await res.text();
  if (opts.ok !== false && !res.ok) throw new Error(`${method} ${url} -> ${res.status}: ${text}`);
  let body: any = text;
  try {
    body = JSON.parse(text);
  } catch {
    // not JSON
  }
  return { status: res.status, body };
}

/** Call one tool over the real MCP endpoint (stateless streamable HTTP), the
 * way an agent does, and return its JSON result. */
export async function mcpCall(baseURL: string, tool: string, args: Json): Promise<Json> {
  const res = await fetch(`${baseURL}/mcp/`, {
    method: "POST",
    headers: { "content-type": "application/json", accept: "application/json, text/event-stream" },
    body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "tools/call", params: { name: tool, arguments: args } }),
    signal: AbortSignal.timeout(30_000),
  });
  const text = await res.text();
  // An SSE reply carries the JSON-RPC message on its `data:` line.
  const data = text.startsWith("{") ? text : text.split("\n").find((l) => l.startsWith("data:"))?.slice(5);
  if (!res.ok || !data) throw new Error(`MCP ${tool} -> ${res.status}: ${text}`);
  const msg = JSON.parse(data);
  expect(msg.error, JSON.stringify(msg)).toBeUndefined();
  expect(msg.result.isError, JSON.stringify(msg)).toBeFalsy();
  return JSON.parse(msg.result.content[0].text);
}

/** Run a statement against ClickHouse over HTTP. POST allows writes (the GET
 * interface is read-only by default), so seeding/teardown go through here. */
export async function chExec(sql: string): Promise<void> {
  const auth = Buffer.from(`${CH_USER}:${CH_PASSWORD}`).toString("base64");
  const res = await fetch(`http://${CH_HOST}:${CH_PORT}/`, {
    method: "POST",
    body: sql,
    headers: { authorization: `Basic ${auth}` },
    signal: AbortSignal.timeout(10_000),
  });
  if (!res.ok) throw new Error(`ClickHouse: ${await res.text()}`);
}

// --- Seeding through the backend's Python ----------------------------------

const PY_EXEC = `
import sys
kind, target, *stmts = sys.argv[1:]
if kind == "postgres":
    import asyncio, os, asyncpg
    async def go():
        c = await asyncpg.connect(host=os.environ["PG_HOST"], port=int(os.environ["PG_PORT"]),
            user=os.environ["PG_USER"], password=os.environ["PG_PASSWORD"] or None, database=target)
        try:
            for s in stmts:
                await c.execute(s)
        finally:
            await c.close()
    asyncio.run(go())
elif kind == "mysql":
    import os, pymysql
    c = pymysql.connect(host=os.environ["MY_HOST"], port=int(os.environ["MY_PORT"]), user=os.environ["MY_USER"],
        password=os.environ["MY_PASSWORD"], database=target or None, autocommit=True)
    with c.cursor() as cur:
        for s in stmts:
            cur.execute(s)
    c.close()
else:
    import duckdb, sqlite3
    con = (duckdb if kind == "duckdb" else sqlite3).connect(target)
    for s in stmts:
        con.execute(s)
    con.commit()
    con.close()
`;

/** Run statements on Postgres/MySQL database `target` ("" for none), or a DuckDB/SQLite file. */
export async function dbExec(kind: "postgres" | "mysql" | "duckdb" | "sqlite", target: string, ...stmts: string[]): Promise<void> {
  await promisify(execFile)(join(VENV_BIN, "python"), ["-c", PY_EXEC, kind, target, ...stmts], {
    env: { ...process.env, PG_HOST, PG_PORT, PG_USER, PG_PASSWORD, MY_HOST, MY_PORT, MY_USER, MY_PASSWORD },
  });
}

const ITEMS_DDL = (t: string) => `CREATE TABLE ${t} (id INTEGER, name TEXT)`;
const ITEMS_ROWS = (t: string) => `INSERT INTO ${t} VALUES (1,'alpha'),(2,'beta'),(3,'gamma')`;

// --- Navigation helpers ----------------------------------------------------

/** Open the app on the Connect page. A previous test's connection can resume
 * on load, so connect flows navigate there explicitly. */
export async function openConnect(page: Page): Promise<void> {
  // No networkidle: the nav renders only once the session is attached.
  await page.goto("/");
  await page.getByTestId("nav-connect").click();
  await expect(page.getByTestId("connect-page")).toBeVisible();
}

/** Open a driver's connection form through the Connect page's "+ New" menu and
 * point it at the suite's server: the form defaults are a passwordless
 * localhost login. */
export async function startNewConnection(page: Page, driver: string): Promise<void> {
  await page.getByTestId("new-menu-toggle").click();
  await page.getByTestId("new-menu").getByTestId(`new-conn-${driver}`).click();
  const servers: Record<string, Record<string, string>> = {
    clickhouse: { "ch-host": CH_HOST, "ch-port": CH_PORT, "ch-username": CH_USER, "ch-password": CH_PASSWORD },
    postgres: { "pg-host": PG_HOST, "pg-port": PG_PORT, "pg-username": PG_USER, "pg-password": PG_PASSWORD },
    mysql: { "my-host": MY_HOST, "my-port": MY_PORT, "my-username": MY_USER, "my-password": MY_PASSWORD },
  };
  for (const [id, value] of Object.entries(servers[driver] ?? {})) await page.getByTestId(id).fill(value);
}

/** Connect to ClickHouse and stop on the database picker. */
export async function openClickhousePicker(page: Page): Promise<void> {
  await openConnect(page);
  await startNewConnection(page, "clickhouse");
  await expect(page.getByTestId("clickhouse-form")).toBeVisible();
  await page.getByTestId("ch-connect").click();
  await expect(page.getByTestId("db-picker")).toBeVisible();
}

export const dashboardFrame = (page: Page): FrameLocator => page.frameLocator('[data-testid="dashboard-frame"]');

export type Dash = { name: string; html: string; queries: Record<string, string>; params?: unknown[] };

/** Save a dashboard through the REST mirror and open it; returns its frame. */
export async function openDashboard(page: Page, baseURL: string | undefined, dash: Dash): Promise<FrameLocator> {
  await api(`${baseURL}/api/dashboards`, { json: dash });
  await page.getByTestId("nav-dashboard").click();
  await page.getByTestId("dashboard-select").selectOption(dash.name);
  return dashboardFrame(page);
}

/** Open a New query draft (ad-hoc SQL: one `<qv-select-view>` under the SQL
 * panel) from wherever the test is; returns the draft's frame. */
export async function openNewQuery(page: Page): Promise<FrameLocator> {
  await page.getByTestId("nav-dashboard").click();
  await page.getByTestId("dashboard-new-query").click();
  await expect(page.getByTestId("dash-sql")).toBeVisible();
  return dashboardFrame(page);
}

/** Type SQL into the dashboard's SQL panel and Execute it. */
export async function executeSql(page: Page, sql: string): Promise<void> {
  await page.getByTestId("dash-sql").fill(sql);
  await page.getByTestId("dash-sql-execute").click();
}

/** Arm remote control via the agent popover and return the session id the
 * popover shows; leaves the popover closed. */
export async function armRemote(page: Page): Promise<string> {
  await page.getByTestId("agent-toggle").click();
  await page.getByTestId("remote-arm").check();
  const sidEl = page.getByTestId("remote-session-id");
  await expect(sidEl).toBeVisible();
  const sessionId = (await sidEl.innerText()).trim();
  expect(sessionId).toBeTruthy();
  await page.getByTestId("agent-toggle").click();
  return sessionId;
}

export const tableRow = (page: Page, name: string) =>
  page.locator(`[data-testid="explorer-table"][data-table="${name}"]`);
export const connCard = (page: Page, name: string) => page.locator(`[data-testid="conn-card"][data-conn="${name}"]`);

export async function switchWorkspace(page: Page, ws: string): Promise<void> {
  await page.getByTestId("workspace-switcher").click();
  await page.getByTestId("workspace-option").filter({ hasText: ws }).click();
  await expect(page.getByTestId("workspace-switcher")).toContainText(ws);
}

export const sessionId = (page: Page): Promise<string> =>
  page.evaluate(() => sessionStorage.getItem("qv_session")!);

// --- Drivers ---------------------------------------------------------------

export type DriverCase = {
  id: string; // also names its form: `${id}-form`
  connectTestid: string; // the Connect button testid
  seed: keyof Seeds; // the `seeds` entry that seeds an `items` table
  pathField?: string; // a file-path field to fill with the seed; without one, a database picker
};

// Every case seeds the same `items(id, name)` table with alpha/beta/gamma.
export const CASES: DriverCase[] = [
  { id: "clickhouse", connectTestid: "ch-connect", seed: "testDb" },
  { id: "postgres", connectTestid: "pg-connect", seed: "pgDb" },
  { id: "mysql", connectTestid: "my-connect", seed: "myDb" },
  { id: "duckdb", connectTestid: "duck-connect", seed: "duckdb", pathField: "duck-path" },
  { id: "sqlite", connectTestid: "sq-connect", seed: "sqlite", pathField: "sq-path" },
];
export const caseById = (id: string) => CASES.find((c) => c.id === id)!;
export const DUCK = caseById("duckdb");
export const CH = caseById("clickhouse");

export async function connect(page: Page, c: DriverCase, seed: string): Promise<void> {
  await openConnect(page);
  await startNewConnection(page, c.id);
  const form = page.getByTestId(`${c.id}-form`);
  await expect(form).toBeVisible();
  if (c.pathField) await page.getByTestId(c.pathField).fill(seed);
  await page.getByTestId(c.connectTestid).click();
  // The status pill can already read "connected" from the session the shell
  // auto-resumed on load, so wait for the form to close: only the connect
  // response's handler dismisses it, and that handler moves on to the picker
  // or the explorer.
  await expect(form).toHaveCount(0);
  if (!c.pathField) {
    await expect(page.getByTestId("db-picker")).toBeVisible();
    await page.locator(`[data-db="${chDb()}"]`).click();
  } else {
    // Picker-less driver (DuckDB, SQLite): connecting goes straight to ready.
    await expect(page.getByTestId("db-picker")).toHaveCount(0);
  }
  await expect(page.getByTestId("connection-status")).toContainText(c.pathField ? c.id : `· ${chDb()}`);
}

/** Start `queryview-backend` on a free port and a throwaway DATA_DIR. */
async function startBackend(): Promise<{ url: string; stop: () => Promise<void> }> {
  const bin = join(VENV_BIN, "queryview-backend");
  if (!existsSync(bin)) throw new Error(`${bin} not found: run \`uv sync\` first`);
  const port = await new Promise<number>((ok) => {
    const srv = createServer().listen(0, () => {
      const p = (srv.address() as { port: number }).port;
      srv.close(() => ok(p));
    });
  });
  const dataDir = mkdtempSync(join(tmpdir(), "qv-e2e-data-"));
  const logPath = join(dataDir, "backend.log");
  const log = createWriteStream(logPath);
  const proc = spawn(bin, [], {
    env: { ...process.env, SERVE_STATIC: "1", PORT: String(port), DATA_DIR: dataDir },
    stdio: ["ignore", "pipe", "pipe"],
  });
  proc.stdout.pipe(log);
  proc.stderr.pipe(log);
  const exited = new Promise((r) => proc.once("exit", r));
  const stop = async () => {
    if (proc.exitCode === null && proc.signalCode === null) {
      proc.kill();
      await Promise.race([exited, new Promise((r) => setTimeout(r, 10_000))]);
      if (proc.exitCode === null && proc.signalCode === null) proc.kill("SIGKILL");
    }
    log.end();
    rmSync(dataDir, { recursive: true, force: true });
  };
  const url = `http://localhost:${port}`;
  const deadline = Date.now() + 60_000;
  for (;;) {
    const up = await fetch(`${url}/api/health`, { signal: AbortSignal.timeout(1000) }).then(
      (r) => r.ok,
      () => false,
    );
    if (up) return { url, stop };
    if (proc.exitCode !== null || Date.now() > deadline) {
      const output = readFileSync(logPath, "utf-8");
      await stop();
      throw new Error(`backend did not come up:\n${output}`);
    }
    await new Promise((r) => setTimeout(r, 100));
  }
}

// --- Fixtures --------------------------------------------------------------

type Seeds = {
  /** ClickHouse database `chDb()` with an `items` table; returns its name. */
  testDb(): Promise<string>;
  /** Postgres database `chDb()` with an `items` table; returns its name. */
  pgDb(): Promise<string>;
  /** MySQL database `chDb()` with an `items` table; returns its name. */
  myDb(): Promise<string>;
  /** A DuckDB file with an `items` table; returns its path. */
  duckdb(): Promise<string>;
  /** A SQLite file with the same `items` table. */
  sqlite(): Promise<string>;
  /** As duckdb, plus invented names too long for the sidebar's default width. */
  duckdbLongNames(): Promise<string>;
  /** Two CSVs at the root (alpha/beta/gamma plus one delta row) and a gzipped CSV in `sub/`. */
  folder(): Promise<string>;
  /** Two CSVs sharing `id` and `name` in a different order, one with an extra `city`. */
  mixedFolder(): Promise<string>;
  /** Twelve CSVs and twelve subfolders, two past an Explorer Max entries of 10. */
  wideFolder(): Promise<string>;
};

export const test = base.extend<
  { shot: (label: string) => Promise<void> },
  { backendURL: string; seeds: Seeds }
>({
  /** The app under test. BASE_URL points at one started separately (then run
   * with --workers 1). Unset, each worker starts its own backend on a free
   * port and a throwaway DATA_DIR, so workers never see each other's
   * connections, workspaces or sessions; only the database servers are shared. */
  backendURL: [
    async ({}, use) => {
      const backend = process.env.BASE_URL ? { url: process.env.BASE_URL, stop: async () => {} } : await startBackend();
      try {
        // The suite saves, renames and deletes freely: never on someone's ~/.queryview.
        if (process.env.BASE_URL) {
          const health = (await (await fetch(`${backend.url}/api/health`)).json()) as { scratch?: boolean };
          if (!health.scratch) throw new Error(`${backend.url} runs on the default data dir; start it with DATA_DIR set`);
        }
        // Point the default workspace at the remote CI stood up, through the
        // same API a user would. Unset locally: git sync stays disabled.
        const remote = process.env.E2E_GIT_REMOTE;
        if (remote) await api(`${backend.url}/api/workspaces/default`, { method: "PATCH", json: { remote } });
        await use(backend.url);
      } finally {
        await backend.stop();
      }
    },
    { scope: "worker", timeout: 90_000 },
  ],

  baseURL: async ({ backendURL }, use) => use(backendURL),

  /** Seeded databases, created on first use in a worker and dropped when it
   * ends. Each drops its target up front too, so a run left behind by a
   * crashed worker never leaks rows into this one. */
  seeds: [
    async ({}, use, workerInfo) => {
      const tmp = mkdtempSync(join(tmpdir(), "qv-e2e-seed-"));
      const db = dbName(workerInfo.parallelIndex);
      const memo = new Map<string, Promise<string>>();
      const once = (key: string, make: () => Promise<string> | string) => () => {
        if (!memo.has(key)) memo.set(key, Promise.resolve(make()));
        return memo.get(key)!;
      };
      const duck = async (name: string, ...tables: string[]) => {
        const path = join(tmp, `${name}.duckdb`);
        await dbExec("duckdb", path, ...tables.flatMap((t) => [ITEMS_DDL(t), ITEMS_ROWS(t)]));
        return path;
      };
      const dir = (name: string, files: Record<string, string | Buffer>) => {
        const root = join(tmp, name);
        for (const [rel, body] of Object.entries(files)) {
          mkdirSync(join(root, rel, ".."), { recursive: true });
          writeFileSync(join(root, rel), body);
        }
        return root;
      };
      const rows = "id,name\n1,alpha\n2,beta\n3,gamma\n";
      const seeds: Seeds = {
        testDb: once("testDb", async () => {
          await chExec(`DROP DATABASE IF EXISTS ${db}`);
          await chExec(`CREATE DATABASE ${db}`);
          await chExec(`CREATE TABLE ${db}.items (id UInt32, name String) ENGINE = MergeTree ORDER BY id`);
          await chExec(ITEMS_ROWS(`${db}.items`));
          return db;
        }),
        pgDb: once("pgDb", async () => {
          await dbExec("postgres", "postgres", `DROP DATABASE IF EXISTS ${db} WITH (FORCE)`, `CREATE DATABASE ${db}`);
          await dbExec("postgres", db, ITEMS_DDL("items"), ITEMS_ROWS("items"));
          return db;
        }),
        myDb: once("myDb", async () => {
          await dbExec("mysql", "", `DROP DATABASE IF EXISTS ${db}`, `CREATE DATABASE ${db}`);
          await dbExec("mysql", db, ITEMS_DDL("items"), ITEMS_ROWS("items"));
          return db;
        }),
        duckdb: once("duckdb", () => duck("qv", "items")),
        sqlite: once("sqlite", async () => {
          const path = join(tmp, "qv.sqlite");
          await dbExec("sqlite", path, ITEMS_DDL("items"), ITEMS_ROWS("items"));
          return path;
        }),
        duckdbLongNames: once("duckdbLongNames", () =>
          duck("long", "items", "sales_reporting_monthly_rollup", "warehouse_shipment_reconciliation_log"),
        ),
        folder: once("folder", () =>
          dir("duck_folder", {
            "items.csv": rows,
            "extra.csv": "id,name\n4,delta\n",
            "sub/nested.csv.gz": gzipSync(rows),
          }),
        ),
        mixedFolder: once("mixedFolder", () =>
          dir("duck_mixed", { "a.csv": "id,name\n1,alpha\n2,beta\n", "b.csv": "name,id,city\ngamma,3,lisbon\n" }),
        ),
        wideFolder: once("wideFolder", () => {
          const files: Record<string, string> = {};
          for (let i = 1; i <= 12; i++) {
            const n = String(i).padStart(2, "0");
            files[`f${n}.csv`] = `id\n${i}\n`;
            mkdirSync(join(tmp, "duck_wide", `d${n}`), { recursive: true });
          }
          return dir("duck_wide", files);
        }),
      };
      await use(seeds);
      if (memo.has("testDb")) await chExec(`DROP DATABASE IF EXISTS ${db}`);
      if (memo.has("pgDb")) await dbExec("postgres", "postgres", `DROP DATABASE IF EXISTS ${db} WITH (FORCE)`);
      if (memo.has("myDb")) await dbExec("mysql", "", `DROP DATABASE IF EXISTS ${db}`);
      rmSync(tmp, { recursive: true, force: true });
    },
    { scope: "worker" },
  ],

  /** Give every test its own session. Session state lives on the server, so a
   * fresh browser context is not fresh state: without this a test would resume
   * the previous one's remembered script, sidebar width and workspace. Seeds
   * `qv_session` but never `qv_tab`, so each page still mints its own tab token
   * and a second tab opened inside a test starts its own session. */
  context: async ({ context, baseURL }, use) => {
    const tab = `e2e-${crypto.randomUUID()}`;
    // `select` with no id always creates a session; `attach` would resume the
    // most recent unheld one — the previous test's, once its tab has released.
    const { body } = await api(`${baseURL}/api/sessions/select`, { json: { tab } });
    expect(body.session.ui, "the context fixture resumed a used session").toEqual({});
    // Release it so the page's own tab token can claim it on load.
    await api(`${baseURL}/api/sessions/release`, { json: { tab } });
    await context.addInitScript((sid) => sessionStorage.setItem("qv_session", sid), body.session.id);
    await use(context);
  },

  /** Save labeled, numbered screenshots into the test's output directory, so
   * an e2e screenshot report can keep call order. Off unless E2E_SHOTS=1:
   * full-page captures cost CI time nobody looks at. */
  shot: async ({ page }, use, testInfo) => {
    let n = 0;
    await use(async (label) => {
      if (process.env.E2E_SHOTS !== "1") return;
      n += 1;
      const safe = label.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "shot";
      await page.screenshot({ path: testInfo.outputPath(`${String(n).padStart(2, "0")}-${safe}.png`), fullPage: true });
    });
  },
});
